<template>
  <div class="home">首页</div>
</template>

<script lang="ts">
import { defineComponent } from "vue";

export default defineComponent({});
</script>
