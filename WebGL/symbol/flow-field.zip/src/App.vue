<template>
  <router-view />
</template>

<style lang="scss">
html,
body {
  margin: 0px;
  padding: 0px;
  height: 100%;
  #app {
    height: 100%;
  }
}
</style>
